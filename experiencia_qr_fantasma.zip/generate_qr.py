# Instala primero: pip install qrcode[pil]
import sys
import qrcode
if len(sys.argv) != 2 or not sys.argv[1].startswith("https://"):
    raise SystemExit("Uso: python generate_qr.py https://TU-USUARIO.github.io/fantasma-ar/")
img = qrcode.make(sys.argv[1])
img.save("qr_fantasma.png")
print("QR guardado como qr_fantasma.png")
