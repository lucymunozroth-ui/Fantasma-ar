# QR de terror con fantasma (realidad aumentada sencilla)

Esta página usa la cámara trasera como fondo y superpone un fantasma animado que aparece de golpe con un efecto de grito generado por el navegador. No graba ni envía video.

## Para que el QR funcione en otros teléfonos
El HTML debe estar publicado en una URL HTTPS pública. Un archivo local o un QR con una ruta de tu computadora no funcionará para otras personas.

### Publicación gratuita con GitHub Pages
1. Inicia sesión o crea una cuenta en https://github.com
2. Crea un repositorio público llamado `fantasma-ar`.
3. Sube `index.html` a la raíz del repositorio.
4. En Settings → Pages, activa la publicación desde la rama `main` y carpeta `/ (root)`.
5. GitHub mostrará una URL parecida a `https://TU-USUARIO.github.io/fantasma-ar/`.
6. Abre esa URL desde el celular y acepta el permiso de cámara.
7. Ejecuta `python generate_qr.py https://TU-USUARIO.github.io/fantasma-ar/` para generar `qr_fantasma.png` con la URL real.

La cámara requiere HTTPS y permiso del usuario. El sonido empieza después de pulsar “INICIAR EXPERIENCIA”, porque los navegadores bloquean audio automático.
